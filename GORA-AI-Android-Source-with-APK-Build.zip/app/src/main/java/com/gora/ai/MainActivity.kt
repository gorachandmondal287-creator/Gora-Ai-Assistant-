package com.gora.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var listenButton: Button
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 9, 18)
        window.navigationBarColor = android.graphics.Color.rgb(5, 9, 18)
        tts = TextToSpeech(this, this)
        buildUi()
        requestMicIfNeeded()
    }

    private fun buildUi() {
        val bg = android.graphics.Color.rgb(5, 9, 18)
        val blue = android.graphics.Color.rgb(45, 150, 255)
        val white = android.graphics.Color.WHITE

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "G O R A   A I"
            textSize = 30f
            setTextColor(blue)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "OFFLINE-FIRST ASSISTANT"
            textSize = 12f
            setTextColor(0xFF9AAFC8.toInt())
            gravity = Gravity.CENTER
        }
        val orb = TextView(this).apply {
            text = "◉"
            textSize = 100f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 20)
        }
        transcript = TextView(this).apply {
            text = "Tap the button and speak.\nYour speech is processed only if an on-device recognizer is available."
            textSize = 16f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 30)
        }
        listenButton = Button(this).apply {
            text = "START LISTENING"
            isAllCaps = false
            setOnClickListener { startListening() }
        }
        val privacy = TextView(this).apply {
            text = "PRIVACY MODE • No app internet permission"
            textSize = 11f
            setTextColor(0xFF79C7A5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(orb)
        layout.addView(transcript)
        layout.addView(listenButton)
        layout.addView(privacy)
        setContentView(layout)
    }

    private fun requestMicIfNeeded() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicIfNeeded()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "NO SPEECH RECOGNIZER"
            transcript.text = "This phone has no compatible speech recognition service."
            return
        }
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            status.text = "ON-DEVICE SPEECH UNAVAILABLE"
            transcript.text = "For privacy, GORA AI will not fall back to an online speech service on this device."
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                status.text = "LISTENING ON DEVICE"
                transcript.text = "Speak now…"
            }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = words?.firstOrNull().orEmpty()
                transcript.text = if (heard.isBlank()) "I didn't catch that." else "You said:\n$heard\n\nStarter version: offline conversation engine is not connected yet."
                status.text = "READY"
                if (heard.isNotBlank() && ttsReady) {
                    tts?.speak("I heard you say $heard. My offline reasoning engine is not connected yet.", TextToSpeech.QUEUE_FLUSH, null, "gora_reply")
                }
            }
            override fun onError(error: Int) {
                status.text = "READY"
                transcript.text = "Speech recognition failed or is unavailable. No online fallback was used. Error: $error"
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "PROCESSING ON DEVICE" }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED)) {
            status.text = "MICROPHONE PERMISSION NEEDED"
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

# GORA AI — Android starter (v0.1.0)

This is a privacy-first starter project, not a finished AI assistant and not a compiled APK.

## Included
- Android app named GORA AI
- Dark / electric-blue starter interface
- Microphone permission requested only when needed
- Attempts Android's on-device speech recognizer only
- No `INTERNET` permission in the manifest
- No cloud API keys, analytics, or network SDKs
- Android text-to-speech response (voice/language depends on installed system TTS engine)

## Important limitations
- This starter does not yet contain an offline language model, wake-word detector, persistent memory, or full phone-control features.
- On-device speech recognition must be supported and available on the phone. If it is unavailable, this app refuses to fall back to online recognition.
- Android system speech/TTS components are outside this app's control. Review the phone's system settings and privacy policy.
- No app can promise absolute privacy against the Android OS, other apps with permissions, device compromise, or user-enabled backups.
- This project has not been built or tested on a physical POCO M3.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose Build > Build Bundle(s) / APK(s) > Build APK(s).
Requires Android SDK 35 and a compatible JDK (typically JDK 17).

Package: `com.gora.ai`
Minimum Android: 8.0 (API 26)
Target SDK: 35


## Build APK automatically with GitHub Actions
1. Upload this project to a GitHub repository you own (the default branch should be `main`).
2. Open the repository's **Actions** tab.
3. Run **Build GORA AI APK** (or push a commit to `main`).
4. When the workflow finishes, open its run and download the `GORA-AI-debug-apk` artifact.
5. Extract the ZIP artifact; it contains `app-debug.apk`.

This workflow creates a debug APK for testing, not a Play Store release APK.
